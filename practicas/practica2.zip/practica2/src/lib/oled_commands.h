#include <SSD1306AsciiWire.h>

void oled_init(uint8_t num);

extern SSD1306AsciiWire oled;